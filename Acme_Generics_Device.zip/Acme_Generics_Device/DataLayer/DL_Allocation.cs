﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace DataLayer
{
    public class DL_Allocation
    {
        public string DL_ValidateBin(string strRackCode, string strMaterialBarcode, string strType, string strUser, string strPlantCode)
        {

            SqlDataLayer objSql = new SqlDataLayer();
            SqlParameter[] objparam = new SqlParameter[6];
            try
            {
                objparam[0] = new SqlParameter("@LOCCODE", SqlDbType.VarChar);
                objparam[1] = new SqlParameter("@MATERIALBARCODE", SqlDbType.VarChar);
                objparam[2] = new SqlParameter("@TYPE", SqlDbType.VarChar);
                objparam[3] = new SqlParameter("@PLANT", SqlDbType.VarChar);
                objparam[4] = new SqlParameter("@USER", SqlDbType.VarChar);
                objparam[5] = new SqlParameter("@RESULT", SqlDbType.VarChar, 500);


                objparam[0].Value = strRackCode;
                objparam[1].Value = strMaterialBarcode;
                objparam[2].Value = strType;
                objparam[3].Value = strPlantCode;
                objparam[4].Value = strUser;
                objparam[5].Direction = ParameterDirection.Output;


                return objSql.ExecuteProcedureParam(objSql.strLocal, "sp_Validae_BinAllocation", objparam, "@RESULT", "@RESULT");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                objSql = null; objparam = null;
            }

        }

        public string DL_ValidateBin_LocationTransfer(string strFromCode,string strToCode, string strMaterialBarcode, string strType, string strUser, string strPlantCode)
        {

            SqlDataLayer objSql = new SqlDataLayer();
            SqlParameter[] objparam = new SqlParameter[7];
            try
            {
                objparam[0] = new SqlParameter("@FROMLOCCODE", SqlDbType.VarChar);
                objparam[1] = new SqlParameter("@TOLOCCODE", SqlDbType.VarChar);
                objparam[2] = new SqlParameter("@MATERIALBARCODE", SqlDbType.VarChar);
                objparam[3] = new SqlParameter("@TYPE", SqlDbType.VarChar);
                objparam[4] = new SqlParameter("@PLANT", SqlDbType.VarChar);
                objparam[5] = new SqlParameter("@USER", SqlDbType.VarChar);
                objparam[6] = new SqlParameter("@RESULT", SqlDbType.VarChar, 500);


                objparam[0].Value = strFromCode;
                objparam[1].Value = strToCode;
                objparam[2].Value = strMaterialBarcode;
                objparam[3].Value = strType;
                objparam[4].Value = strPlantCode;
                objparam[5].Value = strUser;
                objparam[6].Direction = ParameterDirection.Output;


                return objSql.ExecuteProcedureParam(objSql.strLocal, "sp_Validae_LocationTransfer", objparam, "@RESULT", "@RESULT");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                objSql = null; objparam = null;
            }

        }

        public DataTable DL_GetRackDetails(string strRack, string strPlant)
        {
            SqlDataLayer objSql = new SqlDataLayer();
            try
            {
                return objSql.ExecuteDataset(objSql.strLocal, "SELECT DISTINCT A.MATERIALCODE, A.MATERIALBATCH, A.BIN, A.CONT, A.QTY, A.ALLOCATE_BY, A.ALLOCATE_ON, (SELECT TOP 1 CASE WHEN G.UDCODE = '0' THEN 'Undertest' ELSE 'Approved' END FROM TBLGRN_MASTER G WHERE G.ARNO = A.MATERIALBATCH) AS 'STATUS' FROM [TBLSTR_ALLOCATION_T] A WITH (NOLOCK) WHERE BIN = '" + strRack + "' AND PLANTCODE = '" + strPlant + "' AND ISNULL(CONT,0) > 0").Tables[0];
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}
